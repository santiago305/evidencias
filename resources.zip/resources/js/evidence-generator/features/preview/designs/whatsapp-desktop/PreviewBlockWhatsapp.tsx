import { useCallback, useEffect, useMemo, useRef, useState, type CSSProperties } from 'react';
import type { PreviewProps, WhatsappDesktopScale, WhatsappDesktopScaleProps } from '../../../../types';
import { EmptyState } from '../../components/EmptyState';
import { buildContactIdentityDisplay } from './contactIdentityDisplay';
import { buildDesktopCaptureFrameStyle, buildRandomDesktopCaptureFrame } from './desktopCaptureFrame';
import { WhatsappHeaderUser } from './whatsapp-header';
import { buildWhatsappAvatarSeed } from './whatsappAppearance';
import { WhatsappConversation } from './WhatsappConversation';
import type { MsgStatus } from './WhatsappPieces';
import { WhatsappRightAside } from './WhatsappRightAside';

type WinTrayIconProps = {
    glyph: string;
    title?: string;
    className?: string | null;
    iconClassName?: string | null;
};

type TrayIconSpec = {
    key: string;
    glyph: string;
    title: string;
    className?: string | null;
    iconClassName?: string | null;
};

type TrayLanguageSpec = {
    top: string;
    bottom?: string | null;
};

type WindowsTrayProfile = {
    taskbarColor: string;
    icons: TrayIconSpec[];
    language: TrayLanguageSpec;
    languagePosition: 'next-to-hidden' | 'next-to-clock';
};

type WindowsTrayBarProps = {
    profile: WindowsTrayProfile;
};

const HIDDEN_ICONS_SPEC: TrayIconSpec = {
    key: 'hidden-icons',
    glyph: '\uE70E',
    title: 'Mostrar iconos ocultos',
    className: 'min-w-[26px]',
    iconClassName: 'text-[10px]',
};

const NETWORK_ICON_OPTIONS: TrayIconSpec[] = [{ key: 'wifi', glyph: '\uE701', title: 'WiFi', iconClassName: 'text-[14px]' }];

const AUDIO_ICON_OPTIONS: TrayIconSpec[] = [
    { key: 'volume', glyph: '\uE995', title: 'Volumen', className: 'min-w-5.5', iconClassName: 'text-[13px]' },
    { key: 'muted', glyph: '\uE74F', title: 'Silenciado', iconClassName: 'text-[14px]' },
];

const OPTIONAL_TRAY_ICON_POOL: TrayIconSpec[] = [
    { key: 'vpn', glyph: '\uE705', title: 'VPN', iconClassName: 'text-[14px]' },
    { key: 'bluetooth', glyph: '\uE702', title: 'Bluetooth', iconClassName: 'text-[14px]' },
    { key: 'usb', glyph: '\uE88E', title: 'USB', iconClassName: 'text-[14px]' },
    { key: 'printer', glyph: '\uE749', title: 'Impresora', iconClassName: 'text-[14px]' },
    { key: 'microphone', glyph: '\uE720', title: 'Micrófono', iconClassName: 'text-[14px]' },
    { key: 'cloud', glyph: '\uE753', title: 'Cloud / OneDrive', iconClassName: 'text-[14px]' },
    { key: 'defender', glyph: '\uE83D', title: 'Windows Defender', iconClassName: 'text-[14px]' },
    { key: 'notifications', glyph: '\uEB50', title: 'Notificaciones', iconClassName: 'text-[14px]' },
];

const LANGUAGE_OPTIONS: TrayLanguageSpec[] = [{ top: 'ESP', bottom: 'LAA' }, { top: 'ESP' }];
const PERU_TIME_ZONE = 'America/Lima';
const PERU_WINDOWS_CLOCK_FORMATTER = new Intl.DateTimeFormat('es-PE', {
    timeZone: PERU_TIME_ZONE,
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
});

function WinTrayIcon({ glyph, title, className = '', iconClassName = '' }: WinTrayIconProps) {
    return (
        <span title={title} className={`flex h-10 min-w-[20px] items-center justify-center select-none ${className}`}>
            <span
                aria-hidden="true"
                className={`inline-flex items-center justify-center leading-none text-white ${iconClassName}`}
                style={{
                    fontFamily: "'Segoe Fluent Icons', 'Segoe MDL2 Assets'",
                    WebkitFontSmoothing: 'antialiased',
                    MozOsxFontSmoothing: 'grayscale',
                }}
            >
                {glyph}
            </span>
        </span>
    );
}

function hashString(value: string): number {
    let hash = 2166136261;

    for (let index = 0; index < value.length; index += 1) {
        hash ^= value.charCodeAt(index);
        hash = Math.imul(hash, 16777619);
    }

    return hash >>> 0;
}

function createSeededRandom(seed: number): () => number {
    let state = seed || 1;

    return () => {
        state += 0x6d2b79f5;
        let temp = state;
        temp = Math.imul(temp ^ (temp >>> 15), temp | 1);
        temp ^= temp + Math.imul(temp ^ (temp >>> 7), temp | 61);
        return ((temp ^ (temp >>> 14)) >>> 0) / 4294967296;
    };
}

function hslToHex(hue: number, saturation: number, lightness: number): string {
    const h = hue / 360;
    const s = saturation / 100;
    const l = lightness / 100;

    if (s === 0) {
        const gray = Math.round(l * 255)
            .toString(16)
            .padStart(2, '0');
        return `#${gray}${gray}${gray}`;
    }

    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;

    const toChannel = (t: number): string => {
        let value = t;

        if (value < 0) {
            value += 1;
        }
        if (value > 1) {
            value -= 1;
        }

        let channel = p;

        if (value < 1 / 6) {
            channel = p + (q - p) * 6 * value;
        } else if (value < 1 / 2) {
            channel = q;
        } else if (value < 2 / 3) {
            channel = p + (q - p) * (2 / 3 - value) * 6;
        }

        return Math.round(channel * 255)
            .toString(16)
            .padStart(2, '0');
    };

    const red = toChannel(h + 1 / 3);
    const green = toChannel(h);
    const blue = toChannel(h - 1 / 3);

    return `#${red}${green}${blue}`;
}

function normalizeHue(hue: number): number {
    const normalized = hue % 360;
    return normalized < 0 ? normalized + 360 : normalized;
}

function deterministicShuffle<T>(values: T[], random: () => number): T[] {
    const result = [...values];

    for (let index = result.length - 1; index > 0; index -= 1) {
        const randomIndex = Math.floor(random() * (index + 1));
        const currentValue = result[index];
        result[index] = result[randomIndex];
        result[randomIndex] = currentValue;
    }

    return result;
}

function pickOne<T>(values: T[], random: () => number): T {
    return values[Math.floor(random() * values.length)];
}

function randomBoolean(): boolean {
    return Boolean(Math.round(Math.random()));
}

function createRuntimeNonce(): number {
    if (typeof crypto !== 'undefined' && typeof crypto.getRandomValues === 'function') {
        const values = new Uint32Array(1);
        crypto.getRandomValues(values);

        return values[0] ?? Math.floor(Math.random() * Number.MAX_SAFE_INTEGER);
    }

    return Math.floor(Math.random() * Number.MAX_SAFE_INTEGER);
}

function getPixelStyleValue(value: CSSProperties[keyof CSSProperties]): number {
    if (typeof value === 'number') {
        return value;
    }

    if (typeof value === 'string') {
        const parsedValue = Number.parseFloat(value);
        return Number.isFinite(parsedValue) ? parsedValue : 0;
    }

    return 0;
}

function getCaptureFrameStyleDistance(previousStyle: CSSProperties | null, nextStyle: CSSProperties): number {
    if (!previousStyle) {
        return Number.POSITIVE_INFINITY;
    }

    return (
        Math.abs(getPixelStyleValue(previousStyle.top) - getPixelStyleValue(nextStyle.top)) +
        Math.abs(getPixelStyleValue(previousStyle.right) - getPixelStyleValue(nextStyle.right)) +
        Math.abs(getPixelStyleValue(previousStyle.bottom) - getPixelStyleValue(nextStyle.bottom)) +
        Math.abs(getPixelStyleValue(previousStyle.left) - getPixelStyleValue(nextStyle.left))
    );
}

function createWindowsTrayProfile(seedInput: string): WindowsTrayProfile {
    const seed = hashString(seedInput || 'tray-default');
    const random = createSeededRandom(seed);

    const baseHue = normalizeHue(Math.round(random() * 359));
    const saturation = 32 + Math.floor(random() * 26);
    const lightness = 16 + Math.floor(random() * 13);
    const taskbarColor = hslToHex(baseHue, saturation, lightness);

    const networkIcon = pickOne(NETWORK_ICON_OPTIONS, random);
    const audioIcon = pickOne(AUDIO_ICON_OPTIONS, random);

    const optionalIconCount = Math.floor(random() * 5);
    const optionalPool = deterministicShuffle(OPTIONAL_TRAY_ICON_POOL, random);
    const optionalIcons = optionalPool.slice(0, optionalIconCount);

    const icons = deterministicShuffle([networkIcon, audioIcon, ...optionalIcons], random);
    const language = pickOne(LANGUAGE_OPTIONS, random);
    const languagePosition = random() < 0.5 ? 'next-to-hidden' : 'next-to-clock';

    return {
        taskbarColor,
        icons,
        language,
        languagePosition,
    };
}

function renderTrayLanguage(language: TrayLanguageSpec) {
    return (
        <div className="flex h-10 min-w-[39px] flex-col items-center justify-center text-[11px] leading-[14px] tracking-tight text-white">
            <span>{language.top}</span>
            {language.bottom ? <span>{language.bottom}</span> : null}
        </div>
    );
}

function getDateTimePart(parts: Intl.DateTimeFormatPart[], type: Intl.DateTimeFormatPartTypes): string {
    return parts.find((part) => part.type === type)?.value ?? '';
}

function getCurrentPeruWindowsDateTime(date = new Date()): { trayTime: string; trayDate: string } {
    const parts = PERU_WINDOWS_CLOCK_FORMATTER.formatToParts(date);
    const day = getDateTimePart(parts, 'day');
    const month = getDateTimePart(parts, 'month');
    const year = getDateTimePart(parts, 'year');
    const hour = getDateTimePart(parts, 'hour');
    const minute = getDateTimePart(parts, 'minute');

    return {
        trayTime: `${hour}:${minute}`,
        trayDate: `${day}/${month}/${year}`,
    };
}

function useCurrentPeruWindowsDateTime(): { trayTime: string; trayDate: string } {
    const [dateTime, setDateTime] = useState(() => getCurrentPeruWindowsDateTime());

    useEffect(() => {
        let timeoutId: ReturnType<typeof setTimeout> | null = null;

        const scheduleNextMinute = () => {
            const now = new Date();
            const nextMinuteDelay = (60 - now.getSeconds()) * 1000 - now.getMilliseconds() + 50;

            timeoutId = setTimeout(() => {
                setDateTime(getCurrentPeruWindowsDateTime());
                scheduleNextMinute();
            }, nextMinuteDelay);
        };

        setDateTime(getCurrentPeruWindowsDateTime());
        scheduleNextMinute();

        return () => {
            if (timeoutId !== null) {
                clearTimeout(timeoutId);
            }
        };
    }, []);

    return dateTime;
}

function WindowsTrayBar({ profile }: WindowsTrayBarProps) {
    const { trayTime, trayDate } = useCurrentPeruWindowsDateTime();

    return (
        <div
            className="flex h-10 w-full shrink-0 items-center justify-end border-t border-white/10 pr-5 pl-3 text-white shadow-[inset_0_1px_0_rgba(255,255,255,0.08)]"
            style={{
                fontFamily: "'Segoe UI', system-ui, sans-serif",
                backgroundColor: profile.taskbarColor,
            }}
        >
            <div className="flex h-10 items-center gap-0 overflow-hidden">
                <WinTrayIcon
                    glyph={HIDDEN_ICONS_SPEC.glyph}
                    title={HIDDEN_ICONS_SPEC.title}
                    className={HIDDEN_ICONS_SPEC.className ?? ''}
                    iconClassName={HIDDEN_ICONS_SPEC.iconClassName ?? ''}
                />

                {profile.languagePosition === 'next-to-hidden' ? renderTrayLanguage(profile.language) : null}

                {profile.icons.map((icon) => (
                    <WinTrayIcon
                        key={icon.key}
                        glyph={icon.glyph}
                        title={icon.title}
                        className={icon.className ?? ''}
                        iconClassName={icon.iconClassName ?? ''}
                    />
                ))}

                {profile.languagePosition === 'next-to-clock' ? renderTrayLanguage(profile.language) : null}

                {/* Hora y fecha */}
                <div className="ml-[7px] flex h-10 min-w-[50px] flex-col items-end justify-center text-[11px] leading-[14px] tracking-tight text-white">
                    <span id="hora-final-conversacion">{trayTime}</span>
                    <span>{trayDate}</span>
                </div>
            </div>
        </div>
    );
}

type PreviewBlockWhatsappProps = PreviewProps & WhatsappDesktopScaleProps;

const WHATSAPP_DESKTOP_SCALE_FACTORS: Record<WhatsappDesktopScale, number> = {
    80: 1,
    85: 1.05,
    90: 1.1,
    95: 1.15,
    100: 1.2,
};

const WHATSAPP_DESKTOP_MESSAGE_HORIZONTAL_PADDING_PX: Record<WhatsappDesktopScale, number> = {
    80: 63,
    85: 59.29,
    90: 56,
    95: 53.05,
    100: 50.4,
};

const WHATSAPP_DESKTOP_CAPTURE_MAX_WIDTHS: Record<WhatsappDesktopScale, number> = {
    80: 1294,
    85: 1294,
    90: 1287,
    95: 1287,
    100: 1280,
};

const WHATSAPP_RIGHT_ASIDE_WIDTHS: Record<WhatsappDesktopScale, number> = {
    80: 578,
    85: 578,
    90: 578,
    95: 578,
    100: 578,
};

const CAPTURE_FRAME_RANDOM_CANDIDATES = 128;
const CAPTURE_FRAME_RECENT_HISTORY_LIMIT = 5;
const MIN_CAPTURE_FRAME_STYLE_DISTANCE = 64;

export function PreviewBlockWhatsapp({ data, whatsappDesktopScale, themeMode }: PreviewBlockWhatsappProps) {
    const captureRootRef = useRef<HTMLDivElement | null>(null);
    const captureFrameRef = useRef<HTMLDivElement | null>(null);
    const pendingCaptureFrameAnimationRef = useRef<number | null>(null);
    const pendingCaptureFrameTimeoutsRef = useRef<number[]>([]);
    const recentCaptureFrameStylesRef = useRef<CSSProperties[]>([]);
    const [captureFrameStyle, setCaptureFrameStyle] = useState<CSSProperties>({
        top: '0px',
        right: '0px',
        bottom: '0px',
        left: '0px',
    });
    const userSeed = useMemo(() => buildWhatsappAvatarSeed(data ?? undefined), [data]);
    const visualGenerationKey = useMemo(() => createRuntimeNonce(), [data]);
    const desktopScaleFactor = WHATSAPP_DESKTOP_SCALE_FACTORS[whatsappDesktopScale];
    const desktopMessageHorizontalPaddingPx = WHATSAPP_DESKTOP_MESSAGE_HORIZONTAL_PADDING_PX[whatsappDesktopScale];
    const desktopScaledLayoutSize = `${100 / desktopScaleFactor}%`;
    const desktopPreviewStyle = {
        width: desktopScaledLayoutSize,
        height: desktopScaledLayoutSize,
        transform: `scale(${desktopScaleFactor})`,
        transformOrigin: 'top left',
        '--whatsapp-desktop-message-horizontal-padding': `${desktopMessageHorizontalPaddingPx}px`,
    } as CSSProperties;

    const messageStatus = useMemo<MsgStatus>(() => {
        if (data?.previewSnapshot) {
            return data.previewSnapshot.messageStatus;
        }

        const random = createSeededRandom(hashString(`${userSeed}|status`));
        return random() < 0.5 ? 'read' : 'delivered';
    }, [data?.previewSnapshot, userSeed]);

    const temporalBehavior = useMemo(() => {
        if (data?.previewSnapshot) {
            return data.previewSnapshot.temporalBehavior;
        }

        const random = createSeededRandom(hashString(`${userSeed}|temporal`));
        const showsTimerIcon = random() < 0.5;

        if (!showsTimerIcon) {
            const showsTemporalMessagesWhileDisabled = random() < 0.5;

            if (!showsTemporalMessagesWhileDisabled) {
                return {
                    showTemporaryIcon: false,
                    showDefaultTemporalMessage: false,
                    temporalStatusLabel: 'Desactivado' as const,
                    inlineTemporalMode: null,
                };
            }

            return {
                showTemporaryIcon: false,
                showDefaultTemporalMessage: true,
                temporalStatusLabel: 'Desactivado' as const,
                inlineTemporalMode: 'deactive' as const,
            };
        }

        const usesInlineActivationVariant = random() < 0.5;

        if (usesInlineActivationVariant) {
            return {
                showTemporaryIcon: true,
                showDefaultTemporalMessage: false,
                temporalStatusLabel: '90 días' as const,
                inlineTemporalMode: 'active' as const,
            };
        }

        return {
            showTemporaryIcon: true,
            showDefaultTemporalMessage: true,
            temporalStatusLabel: '90 días' as const,
            inlineTemporalMode: null,
        };
    }, [data?.previewSnapshot, userSeed]);

    const contactIdentityDisplay = useMemo(
        () =>
            data
                ? buildContactIdentityDisplay(data)
                : {
                      headerTitle: 'Aracely MD',
                      headerDisplaysPhone: false,
                      profileTitle: 'Sin nombre',
                      profileSubtitle: '+51 —',
                      showAddContactAction: false,
                  },
        [data],
    );

    const showRightInfoPanel = useMemo(() => {
        if (data?.previewSnapshot && typeof data.previewSnapshot?.showRightInfoPanel === 'boolean') {
            return data.previewSnapshot.showRightInfoPanel;
        }

        const random = createSeededRandom(hashString(`${userSeed}|right-info-panel`));
        return random() < 0.5;
    }, [data?.previewSnapshot?.showRightInfoPanel, userSeed]);

    const showRightAside = useMemo(() => {
        if (!contactIdentityDisplay.headerDisplaysPhone) {
            return true;
        }

        return randomBoolean();
    }, [contactIdentityDisplay.headerDisplaysPhone, visualGenerationKey]);
    const rightAsideWidthPx = WHATSAPP_RIGHT_ASIDE_WIDTHS[whatsappDesktopScale] / desktopScaleFactor;
    const captureMaxWidthPx = WHATSAPP_DESKTOP_CAPTURE_MAX_WIDTHS[whatsappDesktopScale];

    const regenerateCaptureFrame = useCallback((): void => {
        const captureRoot = captureRootRef.current;

        if (!captureRoot) {
            return;
        }

        const header = captureRoot.querySelector<HTMLElement>('[data-wa-header]');
        const messageViewport = captureRoot.querySelector<HTMLElement>('[data-wa-message-viewport]');

        if (!header || !messageViewport) {
            return;
        }

        const rightAside = captureRoot.querySelector<HTMLElement>('[data-wa-right-aside]');
        const requiredRightAsideIdentity =
            showRightAside && !contactIdentityDisplay.headerDisplaysPhone
                ? captureRoot.querySelector<HTMLElement>('[data-wa-right-aside-identity]')
                : null;
        const tray = captureRoot.querySelector<HTMLElement>('[data-wa-windows-tray]');
        const rootRect = captureRoot.getBoundingClientRect();
        const headerRect = header.getBoundingClientRect();
        const messageViewportRect = messageViewport.getBoundingClientRect();
        const rightAsideRect = rightAside?.getBoundingClientRect() ?? null;
        const requiredRightAsideIdentityRect = requiredRightAsideIdentity?.getBoundingClientRect() ?? null;
        const trayRect = tray?.getBoundingClientRect() ?? null;
        let nextFrameStyle: CSSProperties | null = null;
        let fallbackFrameStyle: CSSProperties | null = null;

        for (let attempt = 0; attempt < CAPTURE_FRAME_RANDOM_CANDIDATES; attempt += 1) {
            const frame = buildRandomDesktopCaptureFrame({
                rootRect,
                headerRect,
                messageViewportRect,
                rightAsideRect,
                requiredRightAsideIdentityRect,
                trayRect,
            });
            const candidateFrameStyle = buildDesktopCaptureFrameStyle({ frame });

            fallbackFrameStyle = candidateFrameStyle;

            const isDifferentFromRecentFrames = recentCaptureFrameStylesRef.current.every(
                (recentFrameStyle) => getCaptureFrameStyleDistance(recentFrameStyle, candidateFrameStyle) >= MIN_CAPTURE_FRAME_STYLE_DISTANCE,
            );

            if (isDifferentFromRecentFrames) {
                nextFrameStyle = candidateFrameStyle;
                break;
            }
        }

        nextFrameStyle = nextFrameStyle ?? fallbackFrameStyle;

        if (!nextFrameStyle) {
            return;
        }

        recentCaptureFrameStylesRef.current = [nextFrameStyle, ...recentCaptureFrameStylesRef.current].slice(0, CAPTURE_FRAME_RECENT_HISTORY_LIMIT);
        const captureFrame = captureFrameRef.current;

        if (captureFrame) {
            captureFrame.style.top = String(nextFrameStyle.top ?? '0px');
            captureFrame.style.right = String(nextFrameStyle.right ?? '0px');
            captureFrame.style.bottom = String(nextFrameStyle.bottom ?? '0px');
            captureFrame.style.left = String(nextFrameStyle.left ?? '0px');
        }

        setCaptureFrameStyle(nextFrameStyle);
    }, [contactIdentityDisplay.headerDisplaysPhone, showRightAside]);

    const requestCaptureFrameAnimation = useCallback((): void => {
        if (pendingCaptureFrameAnimationRef.current !== null) {
            window.cancelAnimationFrame(pendingCaptureFrameAnimationRef.current);
        }

        pendingCaptureFrameAnimationRef.current = window.requestAnimationFrame(() => {
            pendingCaptureFrameAnimationRef.current = null;
            regenerateCaptureFrame();
        });
    }, [regenerateCaptureFrame]);

    const scheduleCaptureFrameRegeneration = useCallback(
        (delayMs = 0): void => {
            if (delayMs > 0) {
                const timeoutId = window.setTimeout(() => {
                    pendingCaptureFrameTimeoutsRef.current = pendingCaptureFrameTimeoutsRef.current.filter(
                        (pendingTimeoutId) => pendingTimeoutId !== timeoutId,
                    );
                    requestCaptureFrameAnimation();
                }, delayMs);

                pendingCaptureFrameTimeoutsRef.current.push(timeoutId);

                return;
            }

            requestCaptureFrameAnimation();
        },
        [requestCaptureFrameAnimation],
    );

    const clearPendingCaptureFrameWork = useCallback((): void => {
        if (pendingCaptureFrameAnimationRef.current !== null) {
            window.cancelAnimationFrame(pendingCaptureFrameAnimationRef.current);
            pendingCaptureFrameAnimationRef.current = null;
        }

        pendingCaptureFrameTimeoutsRef.current.forEach((timeoutId) => {
            window.clearTimeout(timeoutId);
        });
        pendingCaptureFrameTimeoutsRef.current = [];
    }, []);

    const scheduleCaptureFrameRegenerationBurst = useCallback((): void => {
        clearPendingCaptureFrameWork();

        [0, 48, 132, 260].forEach((delayMs) => {
            scheduleCaptureFrameRegeneration(delayMs);
        });
    }, [clearPendingCaptureFrameWork, scheduleCaptureFrameRegeneration]);

    useEffect(() => {
        scheduleCaptureFrameRegenerationBurst();

        return () => {
            clearPendingCaptureFrameWork();
        };
    }, [
        clearPendingCaptureFrameWork,
        data,
        data?.generatedMessages?.length,
        scheduleCaptureFrameRegenerationBurst,
        showRightAside,
        themeMode,
        visualGenerationKey,
        whatsappDesktopScale,
    ]);

    useEffect(() => {
        const captureRoot = captureRootRef.current;

        if (!captureRoot) {
            return;
        }

        const resizeObserver =
            typeof ResizeObserver === 'undefined'
                ? null
                : new ResizeObserver(() => {
                      scheduleCaptureFrameRegeneration();
                  });

        const observeLayoutTargets = (): void => {
            if (!resizeObserver) {
                return;
            }

            resizeObserver.disconnect();
            resizeObserver.observe(captureRoot);

            const targets = [
                captureRoot.querySelector<HTMLElement>('[data-wa-header]'),
                captureRoot.querySelector<HTMLElement>('[data-wa-message-viewport]'),
                captureRoot.querySelector<HTMLElement>('[data-wa-right-aside]'),
                captureRoot.querySelector<HTMLElement>('[data-wa-right-aside-identity]'),
                captureRoot.querySelector<HTMLElement>('[data-wa-windows-tray]'),
            ];

            targets.forEach((target) => {
                if (target) {
                    resizeObserver.observe(target);
                }
            });
        };

        observeLayoutTargets();

        const mutationObserver =
            typeof MutationObserver === 'undefined'
                ? null
                : new MutationObserver(() => {
                      observeLayoutTargets();
                      scheduleCaptureFrameRegeneration();
                  });

        mutationObserver?.observe(captureRoot, {
            childList: true,
            subtree: true,
        });
        scheduleCaptureFrameRegenerationBurst();

        return () => {
            resizeObserver?.disconnect();
            mutationObserver?.disconnect();
            clearPendingCaptureFrameWork();
        };
    }, [
        clearPendingCaptureFrameWork,
        data,
        data?.generatedMessages?.length,
        scheduleCaptureFrameRegeneration,
        scheduleCaptureFrameRegenerationBurst,
        showRightAside,
        themeMode,
        visualGenerationKey,
        whatsappDesktopScale,
    ]);

    const windowsTrayData = useMemo(() => {
        if (data?.previewSnapshot) {
            return {
                profile: data.previewSnapshot.trayProfile,
            };
        }

        return {
            profile: data?.trayProfile ?? createWindowsTrayProfile(userSeed),
        };
    }, [data?.previewSnapshot, data?.trayProfile, userSeed]);

    if (!data) return <EmptyState />;

    return (
        <div
            ref={captureRootRef}
            data-capture-root="whatsapp-desktop"
            className={['relative flex h-full w-full flex-col overflow-hidden', themeMode === 'dark' ? 'bg-[#0b141a]' : 'bg-[#efeae2]'].join(' ')}
            style={{ maxWidth: `${captureMaxWidthPx}px` }}
        >
            <div
                ref={captureFrameRef}
                id="CAPTURA"
                data-capture-frame="whatsapp-desktop"
                className="pointer-events-none absolute z-50"
                style={captureFrameStyle}
            />

            <div className="min-h-0 w-full flex-1 overflow-hidden">
                <div data-wa-desktop-content className="flex h-full min-h-0 w-full" style={desktopPreviewStyle}>
                    <div className="flex min-w-0 flex-1 flex-col">
                        <WhatsappHeaderUser
                            data={data}
                            status={messageStatus}
                            showTemporaryIndicator={temporalBehavior.showTemporaryIcon}
                            displayTitle={contactIdentityDisplay.headerTitle}
                            themeMode={themeMode}
                        />

                        <WhatsappConversation
                            data={data}
                            messageStatus={messageStatus}
                            messages={data.generatedMessages}
                            showDefaultTemporalMessage={temporalBehavior.showDefaultTemporalMessage}
                            inlineTemporalMode={temporalBehavior.inlineTemporalMode}
                            inlineTemporalInsertIndex={data.previewSnapshot?.inlineTemporalInsertIndex ?? null}
                            displayTitle={contactIdentityDisplay.headerTitle}
                            themeMode={themeMode}
                        />
                    </div>

                    {showRightAside ? (
                        <WhatsappRightAside
                            key={`right-aside-${visualGenerationKey}`}
                            data={data}
                            temporalStatusLabel={temporalBehavior.temporalStatusLabel}
                            profileTitle={contactIdentityDisplay.profileTitle}
                            profileSubtitle={contactIdentityDisplay.profileSubtitle}
                            showAddContactAction={contactIdentityDisplay.showAddContactAction}
                            showInfoPanel={showRightInfoPanel}
                            widthPx={rightAsideWidthPx}
                            themeMode={themeMode}
                        />
                    ) : null}
                </div>
            </div>

            <div data-wa-windows-tray className="shrink-0">
                <WindowsTrayBar profile={windowsTrayData.profile} />
            </div>
        </div>
    );
}
