export function Mobile4WifiIcon() {
    return (
        <svg viewBox="0 0 28 18" className="h-[15px] w-[22px] shrink-0" fill="none" aria-hidden="true">
            <path d="M2.5 6.8C5.3 3.9 9.2 2.2 14 2.2C18.8 2.2 22.7 3.9 25.5 6.8" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M6.1 10.2C8.2 8.1 10.9 6.9 14 6.9C17.1 6.9 19.8 8.1 21.9 10.2" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M9.8 13.1C10.9 12 12.3 11.4 14 11.4C15.7 11.4 17.1 12 18.2 13.1" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" />
            <circle cx="14" cy="15.4" r="1.15" fill="currentColor" />
            <path d="M23.7 15.3V11.7M22.5 12.9 23.7 11.7 24.9 12.9" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M26.7 11.7V15.3M25.5 14.1 26.7 15.3 27.9 14.1" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
    );
}
