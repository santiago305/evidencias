export const mobile4WhatsappLightBackground = '#efeae2';
