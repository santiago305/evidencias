<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('user_conversation_progress', function (Blueprint $table) {
            $table->foreignId('start_conversation_id')
                ->nullable()
                ->after('last_conversation_id')
                ->constrained('conversations')
                ->nullOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('user_conversation_progress', function (Blueprint $table) {
            $table->dropConstrainedForeignId('start_conversation_id');
        });
    }
};
